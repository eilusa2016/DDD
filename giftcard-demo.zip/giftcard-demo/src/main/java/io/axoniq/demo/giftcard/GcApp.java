package io.axoniq.demo.giftcard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GcApp {

    public static void main(String[] args) {
        SpringApplication.run(GcApp.class, args);
    }

}
